# Jeff Koss
# Date: 05/14/2023
# Class: MS548 - Advanced Programming Concepts and AI
# Professor: Jill Coddington
# Assignment: Homework 1 - TextBlob
# ETA: 2 hours

# It took me less than 2 hours to make.


#Imports
from textblob import TextBlob
from textblob import Word


# Menu Function
def languageTranslator():
    playAgain = True
    while (playAgain):
        print("***********************")
        print("* Language Translator *")
        print("***********************")
        print("This program will translate English text into another language.\n")
        print("1. Translate to French.")
        print("2. Translate to Spanish.")
        print("3. Translate to Dutch.")
        print("4. Translate to German")
        print("5. Quit Program.\n")
        translateText = TextBlob(input("Please type the text to be translated here: "))
        choice = input("Please select what language to translate 1-5: ")

        if choice == '1':
           frenchTranslate(translateText)
        elif choice == '2':
           spanishTranslate(translateText)
        elif choice == '3':
            dutchTranslate(translateText)
        elif choice == '4':
            germanTranslate(translateText)
        elif choice == '5':
            playAgain = False
            print("You choose to quit, thank you for playing.")
        else:
            print("Please try again!")

# Translation functions
def frenchTranslate(translateText):
    translateText = translateText.translate(from_lang="en", to="fr")
    print("You choose French, your translated text is: ", translateText)
    return frenchTranslate
def spanishTranslate(translateText):
    translateText = translateText.translate(from_lang="en", to="es")
    print("You choose Spanish, your translated text is: ", translateText)
    return spanishTranslate
def dutchTranslate(translateText):
     translateText = translateText.translate(from_lang="en", to="nl")
     print("You choose Dutch, your translated text is: ", translateText)
     return dutchTranslate
def germanTranslate(translateText):
    translateText = translateText.translate(from_lang="en", to="de")
    print("You choose German, your translated text is: ", translateText)
    return germanTranslate

# Start the program
languageTranslator()